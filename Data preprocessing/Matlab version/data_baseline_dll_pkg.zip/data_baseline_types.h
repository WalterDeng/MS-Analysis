//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// data_baseline_types.h
//
// Code generation for function 'data_baseline'
//

#ifndef DATA_BASELINE_TYPES_H
#define DATA_BASELINE_TYPES_H

// Include files
#include "rtwtypes.h"

#endif
// End of code generation (data_baseline_types.h)
