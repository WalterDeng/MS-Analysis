//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// data_baseline_initialize.cpp
//
// Code generation for function 'data_baseline_initialize'
//

// Include files
#include "data_baseline_initialize.h"
#include "rt_nonfinite.h"

// Function Definitions
void data_baseline_initialize()
{
}

// End of code generation (data_baseline_initialize.cpp)
