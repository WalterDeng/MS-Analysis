//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// data_baseline_data.cpp
//
// Code generation for function 'data_baseline_data'
//

// Include files
#include "data_baseline_data.h"
#include "rt_nonfinite.h"

// End of code generation (data_baseline_data.cpp)
