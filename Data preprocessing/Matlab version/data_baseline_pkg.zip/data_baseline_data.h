//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// data_baseline_data.h
//
// Code generation for function 'data_baseline_data'
//

#ifndef DATA_BASELINE_DATA_H
#define DATA_BASELINE_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
// End of code generation (data_baseline_data.h)
