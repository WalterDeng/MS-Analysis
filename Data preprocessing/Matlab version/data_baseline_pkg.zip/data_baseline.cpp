//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// data_baseline.cpp
//
// Code generation for function 'data_baseline'
//

// Include files
#include "data_baseline.h"
#include "blockedSummation.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Declarations
static double Baseline(coder::array<double, 2U> &x_baselined, double start,
                       double stop, const coder::array<double, 1U> &x,
                       coder::array<double, 2U> &base);

static void b_binary_expand_op(coder::array<double, 2U> &x_baselined, int i1,
                               const coder::array<double, 1U> &x, int i2,
                               int i3, const coder::array<double, 2U> &base,
                               int i4, int i5);

static void binary_expand_op(coder::array<double, 2U> &x_baselined, int i1,
                             const coder::array<double, 1U> &x, int i2, int i3,
                             const coder::array<double, 2U> &a1, int i4,
                             int i5);

// Function Definitions
static double Baseline(coder::array<double, 2U> &x_baselined, double start,
                       double stop, const coder::array<double, 1U> &x,
                       coder::array<double, 2U> &base)
{
  coder::array<double, 2U> c_x;
  coder::array<double, 2U> neg;
  coder::array<int, 2U> ii;
  coder::array<bool, 2U> b_x;
  double S;
  double ex;
  int b_ii;
  int i;
  int i1;
  int idx;
  int nx;
  bool exitg1;
  //  执行数据中单个段落的对齐，该段落由start和stop来界定，
  //  x_baselined为处理后的数据，x为原始数据，base为基线
  if (start > stop) {
    i = 0;
    i1 = 0;
  } else {
    i = static_cast<int>(start) - 1;
    i1 = static_cast<int>(stop);
  }
  nx = i1 - i;
  b_x.set_size(1, nx);
  for (i1 = 0; i1 < nx; i1++) {
    b_x[i1] = (x_baselined[i + i1] < 0.0);
  }
  nx = b_x.size(1);
  idx = 0;
  ii.set_size(1, b_x.size(1));
  b_ii = 0;
  exitg1 = false;
  while ((!exitg1) && (b_ii <= nx - 1)) {
    if (b_x[b_ii]) {
      idx++;
      ii[idx - 1] = b_ii + 1;
      if (idx >= nx) {
        exitg1 = true;
      } else {
        b_ii++;
      }
    } else {
      b_ii++;
    }
  }
  if (b_x.size(1) == 1) {
    if (idx == 0) {
      ii.set_size(1, 0);
    }
  } else {
    if (1 > idx) {
      idx = 0;
    }
    ii.set_size(ii.size(0), idx);
  }
  neg.set_size(1, ii.size(1));
  nx = ii.size(1);
  for (i = 0; i < nx; i++) {
    neg[i] = ii[i];
  }
  // if there are no more than half of V1 instances below zero, the for loop
  // should terminate
  if (neg.size(1) < 3) {
    S = 0.0;
  } else {
    int i2;
    i = neg.size(1);
    neg.set_size(neg.size(0), neg.size(1) + 1);
    neg[i] = rtInf;
    //  zeroes in Ii indicates that two consecetive valeus are below zero, 5 in
    //  a row indicates 6 places below zero in a row
    //  Ii2是一个索引，显示非零的位置
    nx = neg.size(1) - 1;
    c_x.set_size(1, neg.size(1) - 1);
    for (i = 0; i < nx; i++) {
      c_x[i] = (neg[i] - neg[i + 1]) + 1.0;
    }
    nx = c_x.size(1);
    idx = 0;
    ii.set_size(1, c_x.size(1));
    b_ii = 0;
    exitg1 = false;
    while ((!exitg1) && (b_ii <= nx - 1)) {
      if (c_x[b_ii] != 0.0) {
        idx++;
        ii[idx - 1] = b_ii + 1;
        if (idx >= nx) {
          exitg1 = true;
        } else {
          b_ii++;
        }
      } else {
        b_ii++;
      }
    }
    if (c_x.size(1) == 1) {
      if (idx == 0) {
        ii.set_size(1, 0);
      }
    } else {
      if (1 > idx) {
        idx = 0;
      }
      ii.set_size(ii.size(0), idx);
    }
    neg.set_size(1, ii.size(1) + 1);
    neg[0] = 0.0;
    nx = ii.size(1);
    for (i = 0; i < nx; i++) {
      neg[i + 1] = ii[i];
    }
    //  如果范围内只有一个非零
    if (neg.size(1) == 1) {
      double b;
      double b_b;
      double b_b_tmp;
      double b_tmp;
      if (start > stop) {
        i = 0;
        i1 = 0;
      } else {
        i = static_cast<int>(start) - 1;
        i1 = static_cast<int>(stop);
      }
      nx = i1 - i;
      neg.set_size(1, nx);
      for (i1 = 0; i1 < nx; i1++) {
        neg[i1] = x_baselined[i + i1];
      }
      coder::internal::minimum(neg, &ex, &nx);
      S = (static_cast<double>(nx) + start) - 1.0;
      ex = x[static_cast<int>(S) - 1];
      b_tmp = S - start;
      b_b_tmp = x[static_cast<int>(start - 1.0) - 1];
      b = (ex - b_b_tmp) / (b_tmp + 1.0);
      b_b = (x[static_cast<int>(stop + 1.0) - 1] - ex) / ((stop - S) + 1.0);
      if (start > S - 1.0) {
        i = 1;
      } else {
        i = static_cast<int>(start);
      }
      if (std::isnan(b_tmp)) {
        neg.set_size(1, 1);
        neg[0] = rtNaN;
      } else if (b_tmp < 1.0) {
        neg.set_size(1, 0);
      } else {
        nx = static_cast<int>(std::floor(b_tmp - 1.0));
        neg.set_size(1, nx + 1);
        for (i1 = 0; i1 <= nx; i1++) {
          neg[i1] = static_cast<double>(i1) + 1.0;
        }
      }
      nx = neg.size(1);
      for (i1 = 0; i1 < nx; i1++) {
        base[(i + i1) - 1] = b_b_tmp + neg[i1] * b;
      }
      if (S + 1.0 > stop) {
        i = 1;
      } else {
        i = static_cast<int>(S + 1.0);
      }
      b = stop - S;
      if (std::isnan(b)) {
        neg.set_size(1, 1);
        neg[0] = rtNaN;
      } else if (b < 1.0) {
        neg.set_size(1, 0);
      } else {
        nx = static_cast<int>(std::floor(b - 1.0));
        neg.set_size(1, nx + 1);
        for (i1 = 0; i1 <= nx; i1++) {
          neg[i1] = static_cast<double>(i1) + 1.0;
        }
      }
      nx = neg.size(1);
      for (i1 = 0; i1 < nx; i1++) {
        base[(i + i1) - 1] = x[static_cast<int>(S) - 1] + neg[i1] * b_b;
      }
      base[static_cast<int>(S) - 1] = x[static_cast<int>(S) - 1];
    } else {
      nx = neg.size(1) - 1;
      c_x.set_size(1, neg.size(1) - 1);
      for (i = 0; i < nx; i++) {
        c_x[i] = static_cast<int>(neg[i + 1]) - static_cast<int>(neg[i]);
      }
      nx = c_x.size(1);
      if (c_x.size(1) <= 2) {
        if (c_x.size(1) == 1) {
          idx = static_cast<int>(c_x[0]);
        } else if (static_cast<int>(c_x[0]) <
                   static_cast<int>(c_x[c_x.size(1) - 1])) {
          idx = static_cast<int>(c_x[c_x.size(1) - 1]);
        } else {
          idx = static_cast<int>(c_x[0]);
        }
      } else {
        idx = static_cast<int>(c_x[0]);
        for (b_ii = 2; b_ii <= nx; b_ii++) {
          ex = c_x[b_ii - 1];
          if (idx < static_cast<int>(ex)) {
            idx = static_cast<int>(ex);
          }
        }
      }
      if (idx > 3) {
        double b;
        double b_b;
        double b_b_tmp;
        double b_tmp;
        double c_b_tmp;
        if (start > stop) {
          i = 0;
          i1 = 0;
        } else {
          i = static_cast<int>(start) - 1;
          i1 = static_cast<int>(stop);
        }
        nx = i1 - i;
        neg.set_size(1, nx);
        for (i1 = 0; i1 < nx; i1++) {
          neg[i1] = x_baselined[i + i1];
        }
        coder::internal::minimum(neg, &ex, &nx);
        S = (static_cast<double>(nx) + start) - 1.0;
        ex = x[static_cast<int>(S) - 1];
        b_tmp = S - start;
        b_b_tmp = x[static_cast<int>(start - 1.0) - 1];
        b = (ex - b_b_tmp) / (b_tmp + 1.0);
        c_b_tmp = stop - S;
        b_b = (x[static_cast<int>(stop + 1.0) - 1] - ex) / (c_b_tmp + 1.0);
        if (start > S - 1.0) {
          i = 1;
        } else {
          i = static_cast<int>(start);
        }
        if (std::isnan(b_tmp)) {
          neg.set_size(1, 1);
          neg[0] = rtNaN;
        } else if (b_tmp < 1.0) {
          neg.set_size(1, 0);
        } else {
          nx = static_cast<int>(std::floor(b_tmp - 1.0));
          neg.set_size(1, nx + 1);
          for (i1 = 0; i1 <= nx; i1++) {
            neg[i1] = static_cast<double>(i1) + 1.0;
          }
        }
        nx = neg.size(1);
        for (i1 = 0; i1 < nx; i1++) {
          base[(i + i1) - 1] = b_b_tmp + neg[i1] * b;
        }
        if (S + 1.0 > stop) {
          i = 1;
        } else {
          i = static_cast<int>(S + 1.0);
        }
        if (std::isnan(c_b_tmp)) {
          neg.set_size(1, 1);
          neg[0] = rtNaN;
        } else if (c_b_tmp < 1.0) {
          neg.set_size(1, 0);
        } else {
          nx = static_cast<int>(std::floor(c_b_tmp - 1.0));
          neg.set_size(1, nx + 1);
          for (i1 = 0; i1 <= nx; i1++) {
            neg[i1] = static_cast<double>(i1) + 1.0;
          }
        }
        nx = neg.size(1);
        for (i1 = 0; i1 < nx; i1++) {
          base[(i + i1) - 1] = ex + neg[i1] * b_b;
        }
        base[static_cast<int>(S) - 1] = ex;
      } else {
        S = 0.0;
      }
    }
    if (start > stop) {
      i = 0;
      i1 = 0;
      idx = 0;
      b_ii = 0;
      i2 = 0;
    } else {
      i = static_cast<int>(start) - 1;
      i1 = static_cast<int>(stop);
      idx = static_cast<int>(start) - 1;
      b_ii = static_cast<int>(stop);
      i2 = static_cast<int>(start) - 1;
    }
    nx = i1 - i;
    if (nx == b_ii - idx) {
      for (i1 = 0; i1 < nx; i1++) {
        x_baselined[i2 + i1] = x[i + i1] - base[idx + i1];
      }
    } else {
      b_binary_expand_op(x_baselined, i2, x, i, i1 - 1, base, idx, b_ii - 1);
    }
  }
  return S;
}

static void b_binary_expand_op(coder::array<double, 2U> &x_baselined, int i1,
                               const coder::array<double, 1U> &x, int i2,
                               int i3, const coder::array<double, 2U> &base,
                               int i4, int i5)
{
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  stride_0_1 = ((i3 - i2) + 1 != 1);
  stride_1_1 = ((i5 - i4) + 1 != 1);
  if ((i5 - i4) + 1 == 1) {
    loop_ub = (i3 - i2) + 1;
  } else {
    loop_ub = (i5 - i4) + 1;
  }
  for (int i{0}; i < loop_ub; i++) {
    x_baselined[i1 + i] = x[i2 + i * stride_0_1] - base[i4 + i * stride_1_1];
  }
}

static void binary_expand_op(coder::array<double, 2U> &x_baselined, int i1,
                             const coder::array<double, 1U> &x, int i2, int i3,
                             const coder::array<double, 2U> &a1, int i4, int i5)
{
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  stride_0_1 = (i3 - i2 != 1);
  stride_1_1 = (i5 - i4 != 1);
  if (i5 - i4 == 1) {
    loop_ub = i3 - i2;
  } else {
    loop_ub = i5 - i4;
  }
  for (int i{0}; i < loop_ub; i++) {
    x_baselined[(i1 + i) + 1] =
        x[(i2 + i * stride_0_1) + 1] - a1[(i4 + i * stride_1_1) + 1];
  }
}

void data_baseline(const coder::array<double, 1U> &data, double peak_threshold,
                   double smooth_window, double noise_window,
                   coder::array<double, 2U> &data_baselined,
                   coder::array<double, 2U> &base)
{
  coder::array<double, 2U> a1;
  coder::array<double, 2U> x_baselined;
  coder::array<double, 2U> y;
  coder::array<double, 1U> Sx;
  coder::array<double, 1U> absdiff;
  coder::array<double, 1U> x;
  coder::array<bool, 1U> N;
  double iv;
  double scale;
  double t;
  int b_i;
  unsigned int c;
  int i;
  int i1;
  int i2;
  int idx;
  int ii_data;
  int k;
  int n_tmp;
  unsigned int stop_data;
  //  对传入的二维数据data执行平滑、基线校准，并输出为data_baselined,
  //  base为确定的基线
  //    此处显示详细说明
  //  smooth_window, noise_window最好为偶数
  //  peak_threshold = 8000，smooth_window=4，noise_window=6
  // Smoothing (moving average)
  if (data.size(0) < 1) {
    a1.set_size(1, 0);
  } else {
    a1.set_size(1, data.size(0));
    idx = data.size(0) - 1;
    for (i = 0; i <= idx; i++) {
      a1[i] = static_cast<double>(i) + 1.0;
    }
  }
  Sx.set_size(data.size(0));
  idx = data.size(0);
  for (i = 0; i < idx; i++) {
    Sx[i] = 0.0;
  }
  iv = std::round(smooth_window / 2.0);
  // assignin('base','vv',vv);
  // assignin('base','m1',m1);
  //  assignin('base','iv',iv);
  i = static_cast<int>(((static_cast<double>(data.size(0)) - iv) + 1.0) +
                       (1.0 - smooth_window));
  for (b_i = 0; b_i < i; b_i++) {
    double d;
    scale = smooth_window + static_cast<double>(b_i);
    t = a1[static_cast<int>((scale - smooth_window) + 1.0) - 1];
    d = a1[static_cast<int>(scale) - 1];
    if (t > d) {
      i1 = 0;
      i2 = -1;
    } else {
      i1 = static_cast<int>(t) - 1;
      i2 = static_cast<int>(d) - 1;
    }
    idx = i2 - i1;
    absdiff.set_size(idx + 1);
    for (i2 = 0; i2 <= idx; i2++) {
      absdiff[i2] = data[i1 + i2];
    }
    Sx[static_cast<int>((scale - iv) + 1.0) - 1] =
        coder::blockedSummation(absdiff, idx + 1) /
        (static_cast<double>(idx) + 1.0);
  }
  data_baselined.set_size(1, data.size(0));
  idx = data.size(0);
  for (i = 0; i < idx; i++) {
    data_baselined[i] = 0.0;
  }
  base.set_size(1, data.size(0));
  idx = data.size(0);
  for (i = 0; i < idx; i++) {
    base[i] = 0.0;
  }
  // from sample 1 to n1
  idx = data.size(0);
  x.set_size(data.size(0));
  for (i = 0; i < idx; i++) {
    x[i] = data[i];
  }
  a1.set_size(1, data.size(0));
  idx = data.size(0);
  for (i = 0; i < idx; i++) {
    a1[i] = 0.0;
  }
  i = static_cast<int>(static_cast<double>(data.size(0)) - noise_window);
  for (b_i = 0; b_i < i; b_i++) {
    t = ((static_cast<double>(b_i) + 1.0) + noise_window) - 1.0;
    if (static_cast<double>(b_i) + 1.0 > t) {
      i1 = -1;
      i2 = -1;
    } else {
      i1 = b_i - 1;
      i2 = static_cast<int>(t) - 1;
    }
    idx = i2 - i1;
    n_tmp = idx - 1;
    if (idx == 0) {
      a1[b_i] = rtNaN;
    } else if (idx == 1) {
      if ((!std::isinf(Sx[i1 + 1])) && (!std::isnan(Sx[i1 + 1]))) {
        a1[b_i] = 0.0;
      } else {
        a1[b_i] = rtNaN;
      }
    } else {
      absdiff.set_size(idx);
      for (k = 0; k < idx; k++) {
        absdiff[k] = Sx[(i1 + k) + 1];
      }
      iv = coder::blockedSummation(absdiff, idx) / static_cast<double>(idx);
      absdiff.set_size(idx);
      for (k = 0; k <= n_tmp; k++) {
        absdiff[k] = std::abs(Sx[(i1 + k) + 1] - iv);
      }
      iv = 0.0;
      scale = 3.3121686421112381E-170;
      for (k = 0; k <= n_tmp; k++) {
        if (absdiff[k] > scale) {
          t = scale / absdiff[k];
          iv = iv * t * t + 1.0;
          scale = absdiff[k];
        } else {
          t = absdiff[k] / scale;
          iv += t * t;
        }
      }
      iv = scale * std::sqrt(iv);
      a1[b_i] = iv / std::sqrt(static_cast<double>(i2 - i1) - 1.0);
    }
  }
  // Noiese is separated from peaks by making a matrix only containing noise:
  if (1 > data.size(0)) {
    idx = 0;
  } else {
    idx = data.size(0);
  }
  Sx.set_size(idx);
  for (i = 0; i < idx; i++) {
    Sx[i] = data[i];
  }
  i = data.size(0);
  for (b_i = 0; b_i <= i - 6; b_i++) {
    if ((a1[b_i + 5] < peak_threshold) && (a1[b_i] < peak_threshold)) {
      t = data[b_i + 5];
      if (t < 5.0E+8) {
        Sx[b_i + 5] = t;
      } else {
        Sx[b_i + 5] = rtNaN;
      }
    } else {
      Sx[b_i + 5] = rtNaN;
    }
  }
  idx = data.size(0);
  a1.set_size(1, data.size(0));
  for (i = 0; i < idx; i++) {
    a1[i] = data[i];
  }
  // The baseline is estimated as straight line from start to stop of intervals:
  x_baselined.set_size(1, data.size(0));
  idx = data.size(0);
  for (i = 0; i < idx; i++) {
    x_baselined[i] = 0.0;
  }
  N.set_size(Sx.size(0));
  idx = Sx.size(0);
  for (i = 0; i < idx; i++) {
    N[i] = std::isnan(Sx[i]);
  }
  c = 0U;
  i = N.size(0);
  for (b_i = 0; b_i <= i - 2; b_i++) {
    if ((!N[b_i]) && N[b_i + 1] && (c <= static_cast<unsigned int>(b_i + 2))) {
      bool exitg1;
      if (b_i + 2 > N.size(0)) {
        i1 = 0;
        i2 = 0;
      } else {
        i1 = b_i + 1;
        i2 = N.size(0);
      }
      idx = i2 - i1;
      absdiff.set_size(idx);
      for (i2 = 0; i2 < idx; i2++) {
        absdiff[i2] = static_cast<double>(N[i1 + i2]) - 1.0;
      }
      k = (1 <= absdiff.size(0));
      idx = 0;
      n_tmp = 0;
      exitg1 = false;
      while ((!exitg1) && (n_tmp <= absdiff.size(0) - 1)) {
        if (absdiff[n_tmp] != 0.0) {
          idx = 1;
          ii_data = n_tmp + 1;
          exitg1 = true;
        } else {
          n_tmp++;
        }
      }
      if (k == 1) {
        if (idx == 0) {
          k = 0;
        }
      } else {
        k = (1 <= idx);
      }
      for (i1 = 0; i1 < k; i1++) {
        stop_data = static_cast<unsigned int>(ii_data) + b_i;
      }
      c = stop_data + 1U;
      iv = (static_cast<double>(stop_data) - (static_cast<double>(b_i) + 2.0)) +
           1.0;
      scale = (data[static_cast<int>(stop_data)] - data[b_i]) / iv;
      if (static_cast<unsigned int>(b_i + 2) > stop_data) {
        i1 = 0;
      } else {
        i1 = b_i + 1;
      }
      if (iv < 1.0) {
        y.set_size(1, 0);
      } else {
        y.set_size(1, static_cast<int>(iv - 1.0) + 1);
        idx = static_cast<int>(iv - 1.0);
        for (i2 = 0; i2 <= idx; i2++) {
          y[i2] = static_cast<double>(i2) + 1.0;
        }
      }
      idx = y.size(1);
      for (i2 = 0; i2 < idx; i2++) {
        a1[i1 + i2] = data[b_i + 1] + y[i2] * scale;
      }
      if (static_cast<unsigned int>(b_i + 2) > stop_data) {
        i1 = 0;
        i2 = 0;
        k = 0;
        ii_data = 0;
        n_tmp = -1;
      } else {
        i1 = b_i + 1;
        i2 = static_cast<int>(stop_data);
        k = b_i + 1;
        ii_data = static_cast<int>(stop_data);
        n_tmp = b_i;
      }
      idx = i2 - i1;
      if (idx == ii_data - k) {
        for (i2 = 0; i2 < idx; i2++) {
          x_baselined[(n_tmp + i2) + 1] = x[i1 + i2] - a1[k + i2];
        }
      } else {
        binary_expand_op(x_baselined, n_tmp, x, i1 - 1, i2 - 1, a1, k - 1,
                         ii_data - 1);
      }
      iv = Baseline(x_baselined, static_cast<double>(b_i) + 2.0,
                    static_cast<double>(stop_data), x, a1);
      if (iv != 0.0) {
        scale =
            Baseline(x_baselined, static_cast<double>(b_i) + 2.0, iv, x, a1);
        t = Baseline(x_baselined, iv, static_cast<double>(stop_data), x, a1);
        if ((scale != 0.0) && (t != 0.0)) {
          Baseline(x_baselined, static_cast<double>(b_i) + 2.0, scale, x, a1);
          Baseline(x_baselined, scale, iv, x, a1);
          Baseline(x_baselined, iv, t, x, a1);
          Baseline(x_baselined, t, static_cast<double>(stop_data), x, a1);
        } else if (scale != 0.0) {
          Baseline(x_baselined, static_cast<double>(b_i) + 2.0, scale, x, a1);
          Baseline(x_baselined, scale, iv, x, a1);
        } else if (t != 0.0) {
          Baseline(x_baselined, iv, t, x, a1);
          Baseline(x_baselined, t, static_cast<double>(stop_data), x, a1);
        }
      }
    } else if (c < static_cast<unsigned int>(b_i + 2)) {
      a1[b_i + 1] = Sx[b_i + 1];
      x_baselined[b_i + 1] = data[b_i + 1] - a1[b_i + 1];
    }
  }
  // baseline and noise are removed from raw data
  idx = a1.size(1);
  for (i = 0; i < idx; i++) {
    base[i] = a1[i];
  }
  i = data.size(0);
  for (b_i = 0; b_i < i; b_i++) {
    if (x_baselined[b_i] < 0.0) {
      x_baselined[b_i] = 0.0;
    }
  }
  idx = x_baselined.size(1);
  for (i = 0; i < idx; i++) {
    data_baselined[i] = x_baselined[i];
  }
}

// End of code generation (data_baseline.cpp)
