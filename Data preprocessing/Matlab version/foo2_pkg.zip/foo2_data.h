//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_data.h
//
// Code generation for function 'foo2_data'
//

#ifndef FOO2_DATA_H
#define FOO2_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
// End of code generation (foo2_data.h)
