//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_data.cpp
//
// Code generation for function 'foo2_data'
//

// Include files
#include "foo2_data.h"

// End of code generation (foo2_data.cpp)
