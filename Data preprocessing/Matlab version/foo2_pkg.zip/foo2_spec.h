//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_spec.h
//
// Code generation for function 'foo2'
//

#ifndef FOO2_SPEC_H
#define FOO2_SPEC_H

// Include files
#ifdef FOO2_XIL_BUILD
#if defined(_MSC_VER) || defined(__LCC__)
#define FOO2_DLL_EXPORT __declspec(dllimport)
#else
#define FOO2_DLL_EXPORT __attribute__((visibility("default")))
#endif
#elif defined(BUILDING_FOO2)
#if defined(_MSC_VER) || defined(__LCC__)
#define FOO2_DLL_EXPORT __declspec(dllexport)
#else
#define FOO2_DLL_EXPORT __attribute__((visibility("default")))
#endif
#else
#define FOO2_DLL_EXPORT
#endif

#endif
// End of code generation (foo2_spec.h)
