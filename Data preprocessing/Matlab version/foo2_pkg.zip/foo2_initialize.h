//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_initialize.h
//
// Code generation for function 'foo2_initialize'
//

#ifndef FOO2_INITIALIZE_H
#define FOO2_INITIALIZE_H

// Include files
#include "foo2_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
FOO2_DLL_EXPORT extern void foo2_initialize();

#endif
// End of code generation (foo2_initialize.h)
