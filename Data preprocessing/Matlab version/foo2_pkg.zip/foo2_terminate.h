//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_terminate.h
//
// Code generation for function 'foo2_terminate'
//

#ifndef FOO2_TERMINATE_H
#define FOO2_TERMINATE_H

// Include files
#include "foo2_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
FOO2_DLL_EXPORT extern void foo2_terminate();

#endif
// End of code generation (foo2_terminate.h)
