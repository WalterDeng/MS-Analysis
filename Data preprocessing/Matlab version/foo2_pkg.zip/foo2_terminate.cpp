//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_terminate.cpp
//
// Code generation for function 'foo2_terminate'
//

// Include files
#include "foo2_terminate.h"

// Function Definitions
void foo2_terminate()
{
  // (no terminate code required)
}

// End of code generation (foo2_terminate.cpp)
