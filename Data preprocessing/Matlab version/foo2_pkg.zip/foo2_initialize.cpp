//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2_initialize.cpp
//
// Code generation for function 'foo2_initialize'
//

// Include files
#include "foo2_initialize.h"

// Function Definitions
void foo2_initialize()
{
}

// End of code generation (foo2_initialize.cpp)
