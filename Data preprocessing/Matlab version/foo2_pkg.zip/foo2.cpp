//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2.cpp
//
// Code generation for function 'foo2'
//

// Include files
#include "foo2.h"
#include <cmath>

// Function Definitions
double foo2(double a)
{
  return std::sqrt(a);
}

// End of code generation (foo2.cpp)
