//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// foo2.h
//
// Code generation for function 'foo2'
//

#ifndef FOO2_H
#define FOO2_H

// Include files
#include "foo2_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
FOO2_DLL_EXPORT extern double foo2(double a);

#endif
// End of code generation (foo2.h)
